## To excute the script
This code has python files refactored as scripts and are able to install as a package.
All the python scripts are available at `src/housing_price`.
This folder contains `datasets` which has the required datsets along with train and test datasets as csv files.

`housing_price` folder is refactored to a package so it contains `__init__.py`.

This package also contains `tests` folder which has some functional and unit tests for this project.

For installing the `housing_price` package u can just run the below command:

```
(mle-dev) (root-folder)$python setup.py install
```

`setup.py` contains code which will install the required packages and can use as a library.

For running scripts u can run the below command:
I have used argeparse for taking the arguments from the command line:

```
(mle-dev) (script-folder)$python3 <script>.py --args
```

U can run the below code to see what are the options each script takes:

```
(mle-dev) (script-folder)$python <script>.py --help
or
(mle-dev) (script-folder)$python <script>.py -h
```

For running the tests u can just run the below command:

```
(mle-dev) (tests-folder)$py.test
```

These are the required commands for executing this project.

One can install package using housing_price as package name
